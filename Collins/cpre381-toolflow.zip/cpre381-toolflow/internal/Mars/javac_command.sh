#!/bin/bash
cd Mars_Modifications/
javac mars/mips/instructions/InstructionSet.java
cd -
