#!/bin/bash
jar cfm Mars_CPRE381_SIMD_v1.jar Mars_Modifications/mainclass.txt -C Mars_Modifications/ .
